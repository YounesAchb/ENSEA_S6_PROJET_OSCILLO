/*
 * acquisition.h
 *
 *  Created on: Apr 13, 2026
 *      Author: gokay
 */

/**
 * @file    acquisition.h
 * @brief   Module d'acquisition : ADC1 + TIM2 (trigger) + DMA (circular)
 * @details Le DMA fonctionne en mode circulaire sur 1024 échantillons.
 *          Deux callbacks signalent la disponibilité de chaque moitié :
 *            HalfCplt → première moitié (0..511) prête
 *            Cplt     → deuxième moitié (512..1023) prête
 * @author  Gokay
 * @date    2026
 */

#ifndef ACQUISITION_H
#define ACQUISITION_H

#include "main.h"

#define ACQ_BUFFER_SIZE     1024U
#define ACQ_HALF_SIZE       (ACQ_BUFFER_SIZE / 2U)
#define ACQ_VREF_MV         3300U
#define ACQ_ADC_MAX         4095U

typedef enum {
    ACQ_NONE       = 0,
    ACQ_HALF_READY = 1,
    ACQ_FULL_READY = 2
} ACQ_Status_t;

void             ACQ_Start(ADC_HandleTypeDef *hadc, TIM_HandleTypeDef *htim);
void             ACQ_Stop(void);
ACQ_Status_t     ACQ_GetStatus(void);
void             ACQ_ClearStatus(void);
const uint16_t*  ACQ_GetReadyHalf(void);
const uint16_t*  ACQ_GetFullBuffer(void);
uint16_t         ACQ_RawToMillivolts(uint16_t raw);
void             ACQ_Suspend(void);
void             ACQ_Resume(void);

#endif /* ACQUISITION_H */
