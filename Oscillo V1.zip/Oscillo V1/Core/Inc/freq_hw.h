/**
 * @file    freq_hw.h
 * @brief   Mesure de fréquence hardware par Input Capture sur TIM3 CH1 (PB4)
 * @details
 *   Principe :
 *     TIM3 est configuré en Input Capture sur le canal 1, front montant.
 *     À chaque front montant sur PB4, le timer capture sa valeur courante
 *     dans CCR1. On calcule la différence entre deux captures consécutives
 *     pour obtenir la période, puis on en déduit la fréquence.
 *
 *   Paramètres timer :
 *     SYSCLK = 80 MHz, PSC = 79 → TIM3_CLK = 1 MHz (résolution 1 µs)
 *     ARR    = 0xFFFF → débordement toutes les 65,536 ms
 *     Plage mesurable : ~15 Hz → 500 kHz (limité en pratique par l'ADC à 5 kHz)
 *
 *   Câblage physique requis :
 *     La sortie du PGA849 (signal analogique amplifié AVANT le condensateur
 *     de découplage vers PA0) doit être ramenée via un comparateur ou un
 *     circuit de mise en forme (ex. LM393) vers PB4 (signal numérique 0/3.3V).
 *     PB4 = TIM3_CH1 (AF2 sur STM32L476RG).
 *
 *   Gestion du débordement :
 *     Un compteur de débordements (overflow) est incrémenté dans l'ISR
 *     TIM3_IRQHandler pour gérer les signaux très basse fréquence (<15 Hz).
 *     Si plus de 2 débordements se produisent entre deux fronts, la fréquence
 *     est considérée comme indéterminée (retour 0).
 *
 * @author  Gokay
 * @date    2026
 */

#ifndef FREQ_HW_H
#define FREQ_HW_H

#include "main.h"

/* Fréquence d'horloge du timer après diviseur (PSC=79, SYSCLK=80 MHz) */
#define FREQ_HW_TIMER_CLK_HZ    1000000UL   /* 1 MHz → résolution 1 µs */

/* Seuil de débordements : au-delà, signal considéré DC / hors plage */
#define FREQ_HW_OVF_MAX         2U

/**
 * @brief  Initialise TIM3 en mode Input Capture CH1 sur PB4.
 * @param  htim3  Pointeur sur le handle TIM3 (déjà créé dans main.c)
 * @note   Appeler après MX_TIM3_Init() et MX_GPIO_Init().
 *         Cette fonction reconfigure TIM3 (écrase la config Base de main.c).
 */
void FREQ_HW_Init(TIM_HandleTypeDef *htim3);

/**
 * @brief  Retourne la dernière fréquence mesurée en Hz.
 * @return Fréquence en Hz, ou 0 si indéterminée / aucun front reçu récemment.
 */
uint16_t FREQ_HW_GetHz(void);

/**
 * @brief  Callback Input Capture — à appeler depuis HAL_TIM_IC_CaptureCallback.
 *         Calcule la période et met à jour la fréquence.
 * @param  htim  Handle du timer (vérifié == TIM3, canal == TIM_CHANNEL_1)
 */
void FREQ_HW_CaptureCallback(TIM_HandleTypeDef *htim);

/**
 * @brief  Callback débordement — à appeler depuis HAL_TIM_PeriodElapsedCallback.
 *         Incrémente le compteur d'overflow pour détecter les signaux très lents.
 * @param  htim  Handle du timer (vérifié == TIM3)
 */
void FREQ_HW_OverflowCallback(TIM_HandleTypeDef *htim);

#endif /* FREQ_HW_H */
