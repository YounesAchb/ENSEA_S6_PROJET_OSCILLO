/**
 * @file    freq_measure.h
 * @brief   Mesure de fréquence par comptage de passages à zéro (zero-crossing)
 * @details Algorithme :
 *            1. Calcule la moyenne du buffer (référence DC)
 *            2. Compte les fronts montants (sample[i-1] < moy, sample[i] >= moy)
 *            3. freq = nb_fronts * SAMPLE_RATE_HZ / nb_samples
 *
 *          Plage mesurable : 10 Hz → 4 000 Hz (Nyquist à 10 kHz).
 *          En dessous de 10 Hz, la fonction retourne 0 (signal trop lent).
 *
 * @author  Gokay
 * @date    2026
 */

#ifndef FREQ_MEASURE_H
#define FREQ_MEASURE_H

#include "main.h"

/**
 * @brief  Estime la fréquence fondamentale du signal dans le buffer ADC.
 * @param  samples      Pointeur sur les échantillons bruts (12 bits)
 * @param  nb_samples   Nombre d'échantillons dans le buffer
 * @param  sample_rate  Fréquence d'échantillonnage en Hz (ex: 10000)
 * @return Fréquence estimée en Hz, ou 0 si indéterminée / signal DC.
 */
uint16_t FREQ_Estimate(const uint16_t *samples, uint16_t nb_samples,
                       uint32_t sample_rate);

#endif /* FREQ_MEASURE_H */
