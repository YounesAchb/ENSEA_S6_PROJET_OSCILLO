/*
 * protocol.h
 *
 *  Created on: Apr 13, 2026
 *      Author: gokay
 */

/**
 * @file    protocol.h
 * @brief   Protocole de communication avec l'application Java (Android)
 * @details
 *   Trame STM32 → Téléphone :
 *   ┌──────┬──────┬─────┬──────────┬─────────────┬──────────┐
 *   │ 0xAA │ 0x55 │ CMD │ LEN (2B) │ PAYLOAD     │ CHECKSUM │
 *   └──────┴──────┴─────┴──────────┴─────────────┴──────────┘
 *
 *   Commandes téléphone → STM32 : un octet unique
 *     '0'..'7' = changement de gain
 *     'S' = info système,  'P' = pause,  'R' = reprise
 *
 * @author  Gokay
 * @date    2026
 */

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "main.h"

/* ── Header ── */
#define PROTO_HEADER_1          0xAA
#define PROTO_HEADER_2          0x55

/* ── Commandes TX (STM32 → Phone) ── */
#define PROTO_CMD_DATA          0x01
#define PROTO_CMD_ACK           0x02
#define PROTO_CMD_SYSINFO       0x03

/* ── Commandes RX (Phone → STM32) ── */
#define PROTO_RX_GAIN_MIN       '0'
#define PROTO_RX_GAIN_MAX       '7'
#define PROTO_RX_SYSINFO        'S'
#define PROTO_RX_PAUSE          'P'
#define PROTO_RX_RESUME         'R'

/* ── Tailles ── */
#define PROTO_SAMPLES_PER_FRAME 512U
#define PROTO_DATA_PAYLOAD_SIZE (PROTO_SAMPLES_PER_FRAME * 2U)
#define PROTO_DATA_FRAME_SIZE   (2U + 1U + 2U + PROTO_DATA_PAYLOAD_SIZE + 1U)
#define PROTO_ACK_FRAME_SIZE    7U
#define PROTO_SYSINFO_FRAME_SIZE 12U

/* ── Résultats du parseur ── */
#define PROTO_PARSED_NONE       0x00
#define PROTO_PARSED_GAIN       0x01
#define PROTO_PARSED_SYSINFO    0x02
#define PROTO_PARSED_PAUSE      0x03
#define PROTO_PARSED_RESUME     0x04

/* ── API ── */
uint16_t PROTO_BuildDataFrame(uint8_t *tx_buf, const uint16_t *samples, uint16_t nb_samples);
uint16_t PROTO_BuildAckFrame(uint8_t *tx_buf, uint8_t gain_code);
uint16_t PROTO_BuildSysInfoFrame(uint8_t *tx_buf, uint16_t sample_rate,
                                  uint8_t gain_code, uint16_t vref_mv);
uint8_t  PROTO_ParseCommand(uint8_t rx_byte);

#endif /* PROTOCOL_H */
