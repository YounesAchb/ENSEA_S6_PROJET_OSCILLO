
/**
 * @file    pga849.h
 * @brief   Driver pour l'amplificateur à gain programmable PGA849
 * @details Contrôle du gain via 3 GPIO (PA4=A0, PA5=A1, PA6=A2).
 *          Le gain est codé en binaire pur sur 3 bits :
 *            000 = ×1   (calibre max, signaux forts)
 *            111 = ×128 (calibre min, signaux faibles)
 * @author  Gokay
 * @date    2026
 */

#ifndef PGA849_H
#define PGA849_H

#include "main.h"

typedef enum {
    PGA_GAIN_1   = 0x00,
    PGA_GAIN_2   = 0x01,
    PGA_GAIN_4   = 0x02,
    PGA_GAIN_8   = 0x03,
    PGA_GAIN_16  = 0x04,
    PGA_GAIN_32  = 0x05,
    PGA_GAIN_64  = 0x06,
    PGA_GAIN_128 = 0x07
} PGA_Gain_t;

void       PGA_SetGain(PGA_Gain_t gain);
PGA_Gain_t PGA_GetCurrentGain(void);
uint16_t   PGA_GainToMultiplier(PGA_Gain_t gain);

#endif /* PGA849_H */
