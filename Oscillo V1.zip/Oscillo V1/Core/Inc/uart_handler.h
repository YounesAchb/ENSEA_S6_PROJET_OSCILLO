
/**
 * @file    uart_handler.h
 * @brief   Gestionnaire UART pour la communication Bluetooth HC-05
 * @details TX via DMA (non-bloquant), RX par interruption octet par octet.
 *          File circulaire de commandes reçues.
 * @author  Gokay
 * @date    2026
 */

#ifndef UART_HANDLER_H
#define UART_HANDLER_H

#include "main.h"
#include "protocol.h"

#define UART_TX_BUF_SIZE    PROTO_DATA_FRAME_SIZE
#define UART_RX_QUEUE_SIZE  16U

typedef struct {
    uint8_t type;
    uint8_t param;
} UART_Command_t;

void              UART_Init(UART_HandleTypeDef *huart);
HAL_StatusTypeDef UART_SendDMA(const uint8_t *data, uint16_t size);
HAL_StatusTypeDef UART_SendDataFrame(const uint16_t *samples, uint16_t nb_samples);
HAL_StatusTypeDef UART_SendAck(uint8_t gain_code);
HAL_StatusTypeDef UART_SendSysInfo(uint16_t sample_rate, uint8_t gain_code, uint16_t vref_mv);
uint8_t           UART_HasPendingCommand(void);
uint8_t           UART_GetCommand(UART_Command_t *cmd);
uint8_t           UART_IsTxReady(void);

#endif /* UART_HANDLER_H */
