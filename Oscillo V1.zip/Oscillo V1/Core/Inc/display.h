/**
 * @file    display.h
 * @brief   Module d'affichage OLED pour l'oscilloscope
 * @details Gère deux modes d'affichage alternable via le bouton B1 :
 *            MODE_WAVEFORM : courbe du signal + infos compactes en haut
 *            MODE_NUMERIC  : affichage texte Min/Max/Moy/Gain/Freq
 *
 *          La zone de tracé occupe les 44 pixels inférieurs (y=20..63)
 *          sur 128 pixels de large. Chaque colonne x correspond à un
 *          échantillon parmi les 128 sélectionnés dans la demi-trame.
 *
 *          Le trigger cherche un front montant à mi-échelle dans le buffer
 *          pour stabiliser l'affichage avant de sélectionner les 128 points.
 *
 * @author  Gokay
 * @date    2026
 */

#ifndef DISPLAY_H
#define DISPLAY_H

#include "main.h"

/* ── Dimensions de la zone de tracé ── */
#define DISP_WAVE_Y_TOP     20U     /* Ligne de début de la zone signal    */
#define DISP_WAVE_Y_BOT     63U     /* Ligne de fin  de la zone signal     */
#define DISP_WAVE_HEIGHT    (DISP_WAVE_Y_BOT - DISP_WAVE_Y_TOP + 1U)  /* 44 px */
#define DISP_WAVE_WIDTH     128U    /* Largeur = tout l'écran              */

/* ── Paramètres du trigger ── */
#define DISP_TRIG_LEVEL_RAW 2048U   /* Seuil trigger : mi-échelle 12 bits  */
#define DISP_TRIG_SEARCH    256U    /* Fenêtre de recherche (samples)      */

typedef enum {
    DISP_MODE_WAVEFORM = 0,   /* Courbe + infos compactes */
    DISP_MODE_NUMERIC  = 1    /* Texte seul               */
} DISP_Mode_t;

/* ── API publique ── */
void DISP_Init(void);
void DISP_SetMode(DISP_Mode_t mode);
DISP_Mode_t DISP_GetMode(void);
void DISP_ToggleMode(void);

/**
 * @brief  Met à jour l'écran OLED avec les données d'une demi-trame ADC.
 * @param  samples     Pointeur sur les ACQ_HALF_SIZE échantillons bruts
 * @param  nb_samples  Nombre d'échantillons (ACQ_HALF_SIZE = 512)
 * @param  mv_min      Tension min en mV (déjà calculée par main)
 * @param  mv_max      Tension max en mV
 * @param  mv_moy      Tension moyenne en mV
 * @param  freq_hz     Fréquence estimée en Hz (0 = non mesurée)
 * @param  gain_mult   Multiplicateur de gain actuel (1, 2, 4 … 128)
 */
void DISP_Update(const uint16_t *samples, uint16_t nb_samples,
                 uint16_t mv_min, uint16_t mv_max, uint16_t mv_moy,
                 uint16_t freq_hz, uint16_t gain_mult);

#endif /* DISPLAY_H */
