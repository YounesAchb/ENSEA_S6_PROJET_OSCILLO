/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* Bouton utilisateur (Nucleo PC13, actif bas, EXTI15_10) */
#define B1_Pin              GPIO_PIN_13
#define B1_GPIO_Port        GPIOC

/* USART2 / ST-Link Virtual COM */
#define USART_TX_Pin        GPIO_PIN_2
#define USART_TX_GPIO_Port  GPIOA
#define USART_RX_Pin        GPIO_PIN_3
#define USART_RX_GPIO_Port  GPIOA

/* PGA849 — contrôle du gain par 3 GPIO (PA4=A0, PA5=A1, PA6=A2) */
#define PGA_A0_Pin          GPIO_PIN_4
#define PGA_A0_GPIO_Port    GPIOA
#define PGA_A1_Pin          GPIO_PIN_5
#define PGA_A1_GPIO_Port    GPIOA
#define PGA_A2_Pin          GPIO_PIN_6
#define PGA_A2_GPIO_Port    GPIOA

/* TIM3 Input Capture — entrée signal numérique pour mesure de fréquence HW */
#define IC_INPUT_Pin        GPIO_PIN_4
#define IC_INPUT_GPIO_Port  GPIOB   /* PB4 = TIM3_CH1 (AF2) */

/* SWD / debug */
#define TMS_Pin             GPIO_PIN_13
#define TMS_GPIO_Port       GPIOA
#define TCK_Pin             GPIO_PIN_14
#define TCK_GPIO_Port       GPIOA
#define SWO_Pin             GPIO_PIN_3
#define SWO_GPIO_Port       GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
