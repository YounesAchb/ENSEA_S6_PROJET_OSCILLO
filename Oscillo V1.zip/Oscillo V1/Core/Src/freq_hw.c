/**
 * @file    freq_hw.c
 * @brief   Mesure de fréquence hardware par Input Capture TIM3 CH1 (PB4)
 * @author  Gokay
 * @date    2026
 */

#include "freq_hw.h"

/* ── Variables internes (modifiées par ISR) ────────────────────────────────── */

static TIM_HandleTypeDef *p_htim3       = NULL;

static volatile uint32_t capture_prev   = 0;        /* Valeur CCR1 du front N-1  */
static volatile uint8_t  capture_ready  = 0;        /* 1 = premier front reçu    */
static volatile uint8_t  overflow_cnt   = 0;        /* Débordements entre fronts */
static volatile uint16_t freq_hz        = 0;        /* Résultat, lu par main()   */

/* ── Initialisation ─────────────────────────────────────────────────────────── */

/**
 * @brief  Reconfigure TIM3 en Input Capture CH1 sur PB4 (AF2).
 *         PSC=79 → résolution 1 µs avec SYSCLK=80 MHz.
 *         ARR=0xFFFF → débordement toutes les 65,535 ms.
 */
void FREQ_HW_Init(TIM_HandleTypeDef *htim3)
{
    p_htim3 = htim3;

    /* ── Reconfiguration Base TIM3 ── */
    htim3->Instance               = TIM3;
    htim3->Init.Prescaler         = 79U;          /* 80 MHz / (79+1) = 1 MHz   */
    htim3->Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim3->Init.Period            = 0xFFFFU;      /* Débordement à 65535 µs    */
    htim3->Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim3->Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_IC_Init(htim3) != HAL_OK)
        Error_Handler();

    /* ── Configuration Input Capture CH1 ── */
    TIM_IC_InitTypeDef sConfigIC = {0};
    sConfigIC.ICPolarity  = TIM_ICPOLARITY_RISING;   /* Front montant             */
    sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI; /* Signal direct sur CH1    */
    sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;           /* Capture sur chaque front */
    sConfigIC.ICFilter    = 0x08U;  /* Filtre numérique : 8 cycles, anti-bruit    */
    if (HAL_TIM_IC_ConfigChannel(htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
        Error_Handler();

    /* ── Lancement IC + IT débordement ── */
    if (HAL_TIM_IC_Start_IT(htim3, TIM_CHANNEL_1) != HAL_OK)
        Error_Handler();

    /* Active aussi l'interruption de débordement (Update) */
    __HAL_TIM_ENABLE_IT(htim3, TIM_IT_UPDATE);
}

/* ── API publique ────────────────────────────────────────────────────────────── */

uint16_t FREQ_HW_GetHz(void)
{
    return freq_hz;
}

/* ── Callbacks (appelés depuis les ISR HAL) ─────────────────────────────────── */

/**
 * @brief  Appelé par HAL_TIM_IC_CaptureCallback sur chaque front montant.
 *         Calcule la période en µs puis la fréquence en Hz.
 */
void FREQ_HW_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance != TIM3 || htim->Channel != HAL_TIM_ACTIVE_CHANNEL_1)
        return;

    uint32_t val = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);

    if (!capture_ready)
    {
        /* Premier front : on mémorise juste la valeur */
        capture_prev  = val;
        overflow_cnt  = 0;
        capture_ready = 1;
        return;
    }

    /* Trop de débordements → signal hors plage ou DC */
    if (overflow_cnt > FREQ_HW_OVF_MAX)
    {
        freq_hz       = 0;
        capture_prev  = val;
        overflow_cnt  = 0;
        return;
    }

    /* Calcul de la période en µs (compte les débordements) */
    uint32_t period_us;
    if (val >= capture_prev)
    {
        period_us = val - capture_prev;
    }
    else
    {
        /* Débordement entre les deux captures.
         * Guard : overflow_cnt doit être >= 1 ici car val < capture_prev
         * implique que le compteur est reparti de zéro après un overflow.
         * Si overflow_cnt == 0 (cas de rebond/bruit sur PB4), on invalide. */
        if (overflow_cnt == 0U)
        {
            /* Mesure incohérente — réinitialiser sans calculer */
            capture_prev  = val;
            capture_ready = 0;
            return;
        }
        period_us = (0x10000UL - capture_prev) + val
                    + (uint32_t)(overflow_cnt - 1U) * 0x10000UL;
    }

    /* Éviter la division par zéro et les périodes absurdes */
    if (period_us > 0U && period_us < 65536UL)
    {
        /* freq = 1 000 000 / period_us  (timer à 1 MHz) */
        uint32_t f = FREQ_HW_TIMER_CLK_HZ / period_us;
        /* Clamp à uint16 max */
        freq_hz = (f > 65535UL) ? 65535U : (uint16_t)f;
    }
    else
    {
        freq_hz = 0U;
    }

    /* Préparer la prochaine mesure */
    capture_prev = val;
    overflow_cnt = 0;
}

/**
 * @brief  Appelé par HAL_TIM_PeriodElapsedCallback sur chaque débordement TIM3.
 *         Si trop de débordements → signal DC ou très basse fréquence.
 */
void FREQ_HW_OverflowCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance != TIM3)
        return;

    if (overflow_cnt <= FREQ_HW_OVF_MAX)
        overflow_cnt++;
    else
    {
        /* Signal absent ou DC depuis trop longtemps */
        freq_hz       = 0U;
        capture_ready = 0;
        overflow_cnt  = 0;
    }
}

/* ── Surcharge des callbacks HAL __weak ─────────────────────────────────────── */

/**
 * @brief  Surcharge du callback HAL Input Capture (déclaré __weak dans HAL).
 *         Appelé automatiquement par HAL_TIM_IRQHandler sur chaque capture.
 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    FREQ_HW_CaptureCallback(htim);
}

/**
 * @brief  Surcharge du callback HAL débordement (déclaré __weak dans HAL).
 *         Appelé automatiquement par HAL_TIM_IRQHandler sur chaque Update.
 * @note   HAL_ADC_ConvCpltCallback utilise aussi ce nom pour l'ADC → le HAL
 *         distingue les instances. Ici on filtre sur TIM3 dans la fonction.
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    FREQ_HW_OverflowCallback(htim);
}
