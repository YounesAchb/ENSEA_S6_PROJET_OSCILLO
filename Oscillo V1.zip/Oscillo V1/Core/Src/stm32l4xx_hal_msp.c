/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file         stm32l4xx_hal_msp.c
  * @brief        MSP Initialization / De-Initialization
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  *
  * CORRECTIONS APPORTÉES :
  *  - USART1 MspInit : ajout du NVIC pour USART1_IRQn (priorité 3).
  *    Sans ce NVIC activé, HAL_UART_Receive_IT() armait une interruption
  *    qui n'était jamais déclenchée → aucune commande Bluetooth ne pouvait
  *    être reçue. C'est le FIX CRITIQUE #2 (le FIX #1 étant l'ajout de
  *    USART1_IRQHandler dans stm32l4xx_it.c).
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern DMA_HandleTypeDef hdma_adc1;
extern DMA_HandleTypeDef hdma_usart1_tx;

/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  Initialisation globale du MSP.
  */
void HAL_MspInit(void)
{
  /* USER CODE BEGIN MspInit 0 */
  /* USER CODE END MspInit 0 */

  __HAL_RCC_SYSCFG_CLK_ENABLE();
  __HAL_RCC_PWR_CLK_ENABLE();

  /* USER CODE BEGIN MspInit 1 */
  /* USER CODE END MspInit 1 */
}

/**
  * @brief  Initialisation MSP ADC1 :
  *           - Horloge ADC via PLLSAI1 (source indépendante)
  *           - PA0 en mode analogique (ADC1_IN5)
  *           - DMA1 Channel1 en mode circulaire PERIPH→MEM 16 bits
  */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
  GPIO_InitTypeDef       GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  if (hadc->Instance == ADC1)
  {
    /* USER CODE BEGIN ADC1_MspInit 0 */
    /* USER CODE END ADC1_MspInit 0 */

    /* Horloge ADC : PLLSAI1 → ADC1CLK */
    PeriphClkInit.PeriphClockSelection      = RCC_PERIPHCLK_ADC;
    PeriphClkInit.AdcClockSelection         = RCC_ADCCLKSOURCE_PLLSAI1;
    PeriphClkInit.PLLSAI1.PLLSAI1Source    = RCC_PLLSOURCE_HSI;
    PeriphClkInit.PLLSAI1.PLLSAI1M         = 1;
    PeriphClkInit.PLLSAI1.PLLSAI1N         = 8;
    PeriphClkInit.PLLSAI1.PLLSAI1P         = RCC_PLLP_DIV7;
    PeriphClkInit.PLLSAI1.PLLSAI1Q         = RCC_PLLQ_DIV2;
    PeriphClkInit.PLLSAI1.PLLSAI1R         = RCC_PLLR_DIV2;
    PeriphClkInit.PLLSAI1.PLLSAI1ClockOut  = RCC_PLLSAI1_ADC1CLK;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
      Error_Handler();

    __HAL_RCC_ADC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA0 → ADC1_IN5 (broche analogique, pas de résistance de tirage) */
    GPIO_InitStruct.Pin  = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* DMA1 Channel1 : ADC1 → buffer mémoire, circulaire, 16 bits */
    hdma_adc1.Instance                 = DMA1_Channel1;
    hdma_adc1.Init.Request             = DMA_REQUEST_0;
    hdma_adc1.Init.Direction           = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc           = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc              = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc1.Init.MemDataAlignment    = DMA_MDATAALIGN_HALFWORD;
    hdma_adc1.Init.Mode                = DMA_CIRCULAR;
    hdma_adc1.Init.Priority            = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
      Error_Handler();

    __HAL_LINKDMA(hadc, DMA_Handle, hdma_adc1);

    /* USER CODE BEGIN ADC1_MspInit 1 */
    /* USER CODE END ADC1_MspInit 1 */
  }
}

/**
  * @brief  Désinitialisation MSP ADC1
  */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hadc)
{
  if (hadc->Instance == ADC1)
  {
    /* USER CODE BEGIN ADC1_MspDeInit 0 */
    /* USER CODE END ADC1_MspDeInit 0 */
    __HAL_RCC_ADC_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_0);
    HAL_DMA_DeInit(hadc->DMA_Handle);
    /* USER CODE BEGIN ADC1_MspDeInit 1 */
    /* USER CODE END ADC1_MspDeInit 1 */
  }
}

/**
  * @brief  Initialisation MSP I2C1 :
  *           - PB6 = SCL, PB7 = SDA (AF4, open-drain)
  */
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{
  GPIO_InitTypeDef       GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  if (hi2c->Instance == I2C1)
  {
    /* USER CODE BEGIN I2C1_MspInit 0 */
    /* USER CODE END I2C1_MspInit 0 */

    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
    PeriphClkInit.I2c1ClockSelection   = RCC_I2C1CLKSOURCE_PCLK1;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
      Error_Handler();

    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitStruct.Pin       = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    __HAL_RCC_I2C1_CLK_ENABLE();

    /* USER CODE BEGIN I2C1_MspInit 1 */
    /* USER CODE END I2C1_MspInit 1 */
  }
}

/**
  * @brief  Désinitialisation MSP I2C1
  */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef *hi2c)
{
  if (hi2c->Instance == I2C1)
  {
    /* USER CODE BEGIN I2C1_MspDeInit 0 */
    /* USER CODE END I2C1_MspDeInit 0 */
    __HAL_RCC_I2C1_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_6);
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_7);
    /* USER CODE BEGIN I2C1_MspDeInit 1 */
    /* USER CODE END I2C1_MspDeInit 1 */
  }
}

/**
  * @brief  Initialisation MSP Timer (TIM2 en Base, TIM3 en Input Capture)
  * @note   HAL_TIM_Base_MspInit ET HAL_TIM_IC_MspInit partagent les
  *         initialisations GPIO/NVIC pour TIM3 car HAL appelle le MspInit
  *         correspondant au mode configuré. On centralise TIM3 dans IC_MspInit.
  */
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim_base)
{
  if (htim_base->Instance == TIM2)
  {
    /* USER CODE BEGIN TIM2_MspInit 0 */
    /* USER CODE END TIM2_MspInit 0 */
    __HAL_RCC_TIM2_CLK_ENABLE();
    /* USER CODE BEGIN TIM2_MspInit 1 */
    /* USER CODE END TIM2_MspInit 1 */
  }
}

/**
  * @brief  Initialisation MSP TIM3 en mode Input Capture CH1 (PB4, AF2)
  *         PB4 = TIM3_CH1 (Alternate Function 2 sur STM32L476RG)
  *         NVIC TIM3 activé à priorité 4 (entre UART RX=3 et B1=5).
  */
void HAL_TIM_IC_MspInit(TIM_HandleTypeDef *htim_ic)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  if (htim_ic->Instance == TIM3)
  {
    /* USER CODE BEGIN TIM3_MspInit 0 */
    /* USER CODE END TIM3_MspInit 0 */

    __HAL_RCC_TIM3_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* PB4 → TIM3_CH1, AF2, entrée numérique (pull-down : état bas au repos) */
    GPIO_InitStruct.Pin       = GPIO_PIN_4;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_PULLDOWN;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* NVIC TIM3 : gère à la fois l'Input Capture et le débordement (Update) */
    HAL_NVIC_SetPriority(TIM3_IRQn, 4, 0);
    HAL_NVIC_EnableIRQ(TIM3_IRQn);

    /* USER CODE BEGIN TIM3_MspInit 1 */
    /* USER CODE END TIM3_MspInit 1 */
  }
}

/**
  * @brief  Désinitialisation MSP Timer
  */
void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef *htim_base)
{
  if (htim_base->Instance == TIM2)
  {
    __HAL_RCC_TIM2_CLK_DISABLE();
  }
}

/**
  * @brief  Désinitialisation MSP TIM3 Input Capture
  */
void HAL_TIM_IC_MspDeInit(TIM_HandleTypeDef *htim_ic)
{
  if (htim_ic->Instance == TIM3)
  {
    __HAL_RCC_TIM3_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_4);
    HAL_NVIC_DisableIRQ(TIM3_IRQn);
  }
}

/**
  * @brief  Initialisation MSP UART :
  *           USART1 : HC-05 Bluetooth (PA9=TX, PA10=RX) + DMA TX + NVIC RX  ← FIX
  *           USART2 : ST-Link Virtual COM (PA2=TX, PA3=RX)
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
  GPIO_InitTypeDef       GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  if (huart->Instance == USART1)
  {
    /* USER CODE BEGIN USART1_MspInit 0 */
    /* USER CODE END USART1_MspInit 0 */

    PeriphClkInit.PeriphClockSelection  = RCC_PERIPHCLK_USART1;
    PeriphClkInit.Usart1ClockSelection  = RCC_USART1CLKSOURCE_PCLK2;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
      Error_Handler();

    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA9 = TX, PA10 = RX (AF7) */
    GPIO_InitStruct.Pin       = GPIO_PIN_9 | GPIO_PIN_10;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* DMA1 Channel4 : USART1 TX → Bluetooth (normal, non circulaire) */
    hdma_usart1_tx.Instance                 = DMA1_Channel4;
    hdma_usart1_tx.Init.Request             = DMA_REQUEST_2;
    hdma_usart1_tx.Init.Direction           = DMA_MEMORY_TO_PERIPH;
    hdma_usart1_tx.Init.PeriphInc           = DMA_PINC_DISABLE;
    hdma_usart1_tx.Init.MemInc              = DMA_MINC_ENABLE;
    hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_tx.Init.MemDataAlignment    = DMA_MDATAALIGN_BYTE;
    hdma_usart1_tx.Init.Mode                = DMA_NORMAL;
    hdma_usart1_tx.Init.Priority            = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
      Error_Handler();

    __HAL_LINKDMA(huart, hdmatx, hdma_usart1_tx);

    /*
     * FIX CRITIQUE : activation du NVIC pour USART1.
     * Sans cette ligne, l'interruption de réception (armée par
     * HAL_UART_Receive_IT dans UART_Init) ne déclenche jamais
     * USART1_IRQHandler → aucune commande Bluetooth ne peut être reçue.
     *
     * Priorité 3 : inférieure au DMA ADC (1) et DMA UART TX (2)
     * pour ne pas retarder l'acquisition.
     */
    HAL_NVIC_SetPriority(USART1_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);

    /* USER CODE BEGIN USART1_MspInit 1 */
    /* USER CODE END USART1_MspInit 1 */
  }
  else if (huart->Instance == USART2)
  {
    /* USER CODE BEGIN USART2_MspInit 0 */
    /* USER CODE END USART2_MspInit 0 */

    PeriphClkInit.PeriphClockSelection  = RCC_PERIPHCLK_USART2;
    PeriphClkInit.Usart2ClockSelection  = RCC_USART2CLKSOURCE_PCLK1;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
      Error_Handler();

    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA2 = TX, PA3 = RX (AF7, ST-Link) */
    GPIO_InitStruct.Pin       = USART_TX_Pin | USART_RX_Pin;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USER CODE BEGIN USART2_MspInit 1 */
    /* USER CODE END USART2_MspInit 1 */
  }
}

/**
  * @brief  Désinitialisation MSP UART
  */
void HAL_UART_MspDeInit(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    /* USER CODE BEGIN USART1_MspDeInit 0 */
    /* USER CODE END USART1_MspDeInit 0 */
    __HAL_RCC_USART1_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9 | GPIO_PIN_10);
    HAL_DMA_DeInit(huart->hdmatx);
    HAL_NVIC_DisableIRQ(USART1_IRQn);
    /* USER CODE BEGIN USART1_MspDeInit 1 */
    /* USER CODE END USART1_MspDeInit 1 */
  }
  else if (huart->Instance == USART2)
  {
    /* USER CODE BEGIN USART2_MspDeInit 0 */
    /* USER CODE END USART2_MspDeInit 0 */
    __HAL_RCC_USART2_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOA, USART_TX_Pin | USART_RX_Pin);
    /* USER CODE BEGIN USART2_MspDeInit 1 */
    /* USER CODE END USART2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
/* USER CODE END 1 */
