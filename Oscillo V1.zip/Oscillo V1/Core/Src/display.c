/**
 * @file    display.c
 * @brief   Module d'affichage OLED pour l'oscilloscope (SSD1306 128×64)
 * @author  Gokay
 * @date    2026
 *
 * ─── Organisation de l'écran (MODE_WAVEFORM) ───────────────────────────────
 *
 *   Y=0  ┌────────────────────────────────────────────────────────────────┐
 *        │ Min:XXXX  Max:XXXX  xGAIN                          [7x10]      │
 *   Y=10 │ Moy:XXXX mV   Freq: XXXX Hz                       [7x10]      │
 *   Y=19 ├────────────────────────────────────────────────────────────────┤  ← ligne séparatrice
 *   Y=20 │                                                                │
 *        │                 ZONE DE TRACÉ (44 px)                          │
 *        │       Forme d'onde avec trigger sur front montant               │
 *   Y=63 └────────────────────────────────────────────────────────────────┘
 *
 * ─── Algorithme de trigger ─────────────────────────────────────────────────
 *   Recherche dans les 256 premiers samples d'un front montant autour du
 *   seuil DISP_TRIG_LEVEL_RAW (mi-échelle). On commence l'affichage à cet
 *   index pour que la courbe soit stable à chaque rafraîchissement.
 *   Si aucun trigger n'est trouvé, on affiche depuis l'index 0.
 *
 * ─── Mapping amplitude → pixel Y ───────────────────────────────────────────
 *   raw=0    → y = DISP_WAVE_Y_BOT   (bas de la zone)
 *   raw=4095 → y = DISP_WAVE_Y_TOP   (haut de la zone)
 *   Formule : y = DISP_WAVE_Y_BOT - (raw * DISP_WAVE_HEIGHT / ACQ_ADC_MAX)
 */

#include "display.h"
#include "acquisition.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include <stdio.h>

/* ── État interne ── */
static DISP_Mode_t current_mode = DISP_MODE_WAVEFORM;

/* ── Fonctions internes ── */

/**
 * @brief  Cherche l'index de départ du trigger (front montant à mi-échelle).
 * @param  samples     Buffer d'échantillons
 * @param  nb_samples  Taille du buffer
 * @return Index du premier sample après le front montant, ou 0 si non trouvé.
 */
static uint16_t find_trigger(const uint16_t *samples, uint16_t nb_samples)
{
    /* On ne cherche que dans la première moitié pour garder 128 points après */
    uint16_t search_end = nb_samples - DISP_WAVE_WIDTH;
    if (search_end > DISP_TRIG_SEARCH)
        search_end = DISP_TRIG_SEARCH;

    for (uint16_t i = 1; i < search_end; i++)
    {
        /* Front montant : sample précédent sous le seuil, courant au-dessus */
        if (samples[i - 1] < DISP_TRIG_LEVEL_RAW &&
            samples[i]     >= DISP_TRIG_LEVEL_RAW)
        {
            return i;
        }
    }
    return 0U;  /* Pas de trigger trouvé : début du buffer */
}

/**
 * @brief  Convertit une valeur ADC brute en coordonnée Y OLED.
 *         raw=0 → bas (Y_BOT), raw=4095 → haut (Y_TOP).
 */
static uint8_t raw_to_y(uint16_t raw)
{
    uint32_t y = DISP_WAVE_Y_BOT -
                 ((uint32_t)raw * DISP_WAVE_HEIGHT / ACQ_ADC_MAX);
    if (y < DISP_WAVE_Y_TOP) y = DISP_WAVE_Y_TOP;
    if (y > DISP_WAVE_Y_BOT) y = DISP_WAVE_Y_BOT;
    return (uint8_t)y;
}

/**
 * @brief  Affiche la forme d'onde + infos compactes en haut.
 */
static void draw_waveform(const uint16_t *samples, uint16_t nb_samples,
                          uint16_t mv_min, uint16_t mv_max, uint16_t mv_moy,
                          uint16_t freq_hz, uint16_t gain_mult)
{
    char line[22];

    ssd1306_Fill(Black);

    /* ── Ligne 0 : Min / Max / Gain ── */
    ssd1306_SetCursor(0, 0);
    snprintf(line, sizeof(line), "%u/%u mV x%u", mv_min, mv_max, gain_mult);
    ssd1306_WriteString(line, Font_7x10, White);

    /* ── Ligne 1 : Moy / Fréquence ── */
    ssd1306_SetCursor(0, 10);
    if (freq_hz > 0U)
        snprintf(line, sizeof(line), "~%u mV %uHz", mv_moy, freq_hz);
    else
        snprintf(line, sizeof(line), "~%u mV  ----", mv_moy);
    ssd1306_WriteString(line, Font_7x10, White);

    /* ── Ligne séparatrice ── */
    ssd1306_Line(0, 19, 127, 19, White);

    /* ── Tracé de la forme d'onde ── */
    uint16_t trig_idx = find_trigger(samples, nb_samples);

    /* S'assurer qu'on a bien 128 points disponibles après le trigger */
    if (trig_idx + DISP_WAVE_WIDTH > nb_samples)
        trig_idx = 0U;

    uint8_t y_prev = raw_to_y(samples[trig_idx]);

    for (uint8_t x = 0; x < DISP_WAVE_WIDTH; x++)
    {
        uint8_t y_cur = raw_to_y(samples[trig_idx + x]);

        /* Tracer une ligne verticale entre le point précédent et le courant
         * pour éviter les trous lors de signaux à forte pente */
        if (x == 0)
        {
            ssd1306_DrawPixel(x, y_cur, White);
        }
        else
        {
            ssd1306_Line(x - 1U, y_prev, x, y_cur, White);
        }
        y_prev = y_cur;
    }

    ssd1306_UpdateScreen();
}

/**
 * @brief  Affiche uniquement les valeurs numériques (mode texte).
 */
static void draw_numeric(uint16_t mv_min, uint16_t mv_max, uint16_t mv_moy,
                         uint16_t freq_hz, uint16_t gain_mult)
{
    char line[22];

    ssd1306_Fill(Black);

    ssd1306_SetCursor(0, 0);
    snprintf(line, sizeof(line), "Min : %4u mV", mv_min);
    ssd1306_WriteString(line, Font_7x10, White);

    ssd1306_SetCursor(0, 12);
    snprintf(line, sizeof(line), "Max : %4u mV", mv_max);
    ssd1306_WriteString(line, Font_7x10, White);

    ssd1306_SetCursor(0, 24);
    snprintf(line, sizeof(line), "Moy : %4u mV", mv_moy);
    ssd1306_WriteString(line, Font_7x10, White);

    ssd1306_SetCursor(0, 36);
    snprintf(line, sizeof(line), "Gain: x%u", gain_mult);
    ssd1306_WriteString(line, Font_7x10, White);

    ssd1306_SetCursor(0, 48);
    if (freq_hz > 0U)
        snprintf(line, sizeof(line), "Freq: %u Hz", freq_hz);
    else
        snprintf(line, sizeof(line), "Freq: ---- Hz");
    ssd1306_WriteString(line, Font_7x10, White);

    ssd1306_UpdateScreen();
}

/* ── API publique ─────────────────────────────────────────────────────────── */

void DISP_Init(void)
{
    current_mode = DISP_MODE_WAVEFORM;
}

void DISP_SetMode(DISP_Mode_t mode)
{
    current_mode = mode;
}

DISP_Mode_t DISP_GetMode(void)
{
    return current_mode;
}

void DISP_ToggleMode(void)
{
    current_mode = (current_mode == DISP_MODE_WAVEFORM)
                   ? DISP_MODE_NUMERIC
                   : DISP_MODE_WAVEFORM;
}

void DISP_Update(const uint16_t *samples, uint16_t nb_samples,
                 uint16_t mv_min, uint16_t mv_max, uint16_t mv_moy,
                 uint16_t freq_hz, uint16_t gain_mult)
{
    if (current_mode == DISP_MODE_WAVEFORM)
        draw_waveform(samples, nb_samples, mv_min, mv_max, mv_moy,
                      freq_hz, gain_mult);
    else
        draw_numeric(mv_min, mv_max, mv_moy, freq_hz, gain_mult);
}
