

/**
 * @file    protocol.c
 * @brief   Implémentation du protocole Bluetooth
 * @author  Gokay
 * @date    2026
 */

#include "protocol.h"

/* Calcul du checksum XOR sur les octets après le header */
static uint8_t compute_checksum(const uint8_t *data, uint16_t len)
{
    uint8_t xor_val = 0;
    for (uint16_t i = 0; i < len; i++)
        xor_val ^= data[i];
    return xor_val;
}

uint16_t PROTO_BuildDataFrame(uint8_t *tx_buf, const uint16_t *samples, uint16_t nb_samples)
{
    uint16_t idx = 0;
    uint16_t payload_len = nb_samples * 2U;

    tx_buf[idx++] = PROTO_HEADER_1;
    tx_buf[idx++] = PROTO_HEADER_2;
    tx_buf[idx++] = PROTO_CMD_DATA;
    tx_buf[idx++] = (uint8_t)(payload_len >> 8);
    tx_buf[idx++] = (uint8_t)(payload_len & 0xFF);

    /* Échantillons en big-endian (natif Java) */
    for (uint16_t i = 0; i < nb_samples; i++)
    {
        tx_buf[idx++] = (uint8_t)(samples[i] >> 8);
        tx_buf[idx++] = (uint8_t)(samples[i] & 0xFF);
    }

    tx_buf[idx] = compute_checksum(&tx_buf[2], idx - 2);
    idx++;
    return idx;
}

uint16_t PROTO_BuildAckFrame(uint8_t *tx_buf, uint8_t gain_code)
{
    uint16_t idx = 0;
    tx_buf[idx++] = PROTO_HEADER_1;
    tx_buf[idx++] = PROTO_HEADER_2;
    tx_buf[idx++] = PROTO_CMD_ACK;
    tx_buf[idx++] = 0x00;
    tx_buf[idx++] = 0x01;
    tx_buf[idx++] = gain_code;
    tx_buf[idx] = compute_checksum(&tx_buf[2], idx - 2);
    idx++;
    return idx;
}

uint16_t PROTO_BuildSysInfoFrame(uint8_t *tx_buf, uint16_t sample_rate,
                                  uint8_t gain_code, uint16_t vref_mv)
{
    uint16_t idx = 0;
    tx_buf[idx++] = PROTO_HEADER_1;
    tx_buf[idx++] = PROTO_HEADER_2;
    tx_buf[idx++] = PROTO_CMD_SYSINFO;
    tx_buf[idx++] = 0x00;
    tx_buf[idx++] = 0x05;
    tx_buf[idx++] = (uint8_t)(sample_rate >> 8);
    tx_buf[idx++] = (uint8_t)(sample_rate & 0xFF);
    tx_buf[idx++] = gain_code;
    tx_buf[idx++] = (uint8_t)(vref_mv >> 8);
    tx_buf[idx++] = (uint8_t)(vref_mv & 0xFF);
    tx_buf[idx] = compute_checksum(&tx_buf[2], idx - 2);
    idx++;
    return idx;
}

uint8_t PROTO_ParseCommand(uint8_t rx_byte)
{
    if (rx_byte >= PROTO_RX_GAIN_MIN && rx_byte <= PROTO_RX_GAIN_MAX)
        return PROTO_PARSED_GAIN;
    if (rx_byte == PROTO_RX_SYSINFO)
        return PROTO_PARSED_SYSINFO;
    if (rx_byte == PROTO_RX_PAUSE)
        return PROTO_PARSED_PAUSE;
    if (rx_byte == PROTO_RX_RESUME)
        return PROTO_PARSED_RESUME;
    return PROTO_PARSED_NONE;
}
