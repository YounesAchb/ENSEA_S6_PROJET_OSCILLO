/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Oscilloscope portable STM32L476RG — Programme principal
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "pga849.h"
#include "acquisition.h"
#include "protocol.h"
#include "uart_handler.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "display.h"
#include "freq_measure.h"   /* Mesure logicielle (zero-crossing, backup)     */
#include "freq_hw.h"        /* Mesure hardware TIM3 Input Capture sur PB4    */
#include <stdio.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SAMPLE_RATE_HZ      10000U

/*
 * Throttle OLED : on ne rafraîchit l'écran que toutes les N trames.
 * À 10 kHz, une demi-trame = 512 samples = 51 ms.
 * 4 trames ≈ 200 ms → ~5 fps, suffisant pour un affichage lisible
 * sans saturer l'I2C (400 kHz).
 */
#define OLED_REFRESH_EVERY  4U

/*
 * Anti-rebond bouton B1 :
 * Le bouton est sur PC13, actif à l'état bas. On impose un délai minimum
 * de 200 ms entre deux appuis valides pour filtrer les rebonds mécaniques.
 */
#define BTN_DEBOUNCE_MS     200U
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef  hadc1;
DMA_HandleTypeDef  hdma_adc1;

I2C_HandleTypeDef  hi2c1;

TIM_HandleTypeDef  htim2;
TIM_HandleTypeDef  htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef  hdma_usart1_tx;

/* USER CODE BEGIN PV */
static uint8_t  app_running    = 1;
static uint32_t oled_frame_cnt = 0;   /* Compteur pour throttle OLED  */
static uint32_t btn_last_tick  = 0;   /* Timestamp dernier appui B1   */
static volatile uint8_t btn_pressed = 0;  /* Drapeau ISR → main loop  */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM3_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
static void App_ProcessCommands(void);
static void App_HandleGainChange(uint8_t gain_code);
static void App_ProcessButton(void);
static void App_ShowPause(void);
static void App_ShowResume(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
 * @brief  Traite toutes les commandes Bluetooth en attente dans la file RX
 */
static void App_ProcessCommands(void)
{
    UART_Command_t cmd;

    while (UART_HasPendingCommand())
    {
        if (!UART_GetCommand(&cmd))
            break;

        switch (cmd.type)
        {
            case PROTO_PARSED_GAIN:
                App_HandleGainChange(cmd.param);
                break;

            case PROTO_PARSED_SYSINFO:
                UART_SendSysInfo(SAMPLE_RATE_HZ,
                                 (uint8_t)PGA_GetCurrentGain(),
                                 ACQ_VREF_MV);
                break;

            case PROTO_PARSED_PAUSE:
                ACQ_Suspend();
                app_running = 0;
                App_ShowPause();
                break;

            case PROTO_PARSED_RESUME:
                ACQ_Resume();
                app_running = 1;
                App_ShowResume();
                break;

            default:
                break;
        }
    }
}

/**
 * @brief  Changement de gain sécurisé (suspend ADC → change PGA → reprend)
 * @param  gain_code  Code de gain 0..7
 */
static void App_HandleGainChange(uint8_t gain_code)
{
    ACQ_Suspend();
    PGA_SetGain((PGA_Gain_t)gain_code);
    HAL_Delay(1);          /* Settling time du PGA849 */
    if (app_running)
        ACQ_Resume();
    UART_SendAck(gain_code);
}

/**
 * @brief  Traite l'appui bouton B1 avec anti-rebond logiciel.
 *         Action : basculer entre MODE_WAVEFORM et MODE_NUMERIC.
 * @note   btn_pressed est mis à 1 par HAL_GPIO_EXTI_Callback (ISR).
 */
static void App_ProcessButton(void)
{
    if (!btn_pressed)
        return;

    btn_pressed = 0;

    uint32_t now = HAL_GetTick();
    if ((now - btn_last_tick) < BTN_DEBOUNCE_MS)
        return;   /* Rebond → ignorer */

    btn_last_tick = now;
    DISP_ToggleMode();
}

/**
 * @brief  Affiche un écran "PAUSE" sur l'OLED quand l'acquisition est suspendue.
 */
static void App_ShowPause(void)
{
    ssd1306_Fill(Black);
    ssd1306_SetCursor(16, 18);
    ssd1306_WriteString("  PAUSE  ", Font_11x18, White);
    ssd1306_SetCursor(14, 42);
    ssd1306_WriteString("Appui B1: reprend", Font_6x8, White);
    ssd1306_UpdateScreen();
}

/**
 * @brief  Efface l'écran de pause — le prochain DISP_Update() reprend l'affichage normal.
 */
static void App_ShowResume(void)
{
    ssd1306_Fill(Black);
    ssd1306_UpdateScreen();
}

/**
 * @brief  Callback EXTI déclenché sur le front descendant de B1 (PC13).
 *         N'effectue aucun traitement ici (ISR courte) — pose juste un drapeau.
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == B1_Pin)
        btn_pressed = 1;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration -------------------------------------------------------*/
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();

  /* USER CODE BEGIN 2 */

  /* ═══ Init OLED + module display ═══ */
  ssd1306_Init();
  DISP_Init();   /* mode WAVEFORM par défaut */

  ssd1306_Fill(Black);
  ssd1306_SetCursor(0, 0);
  ssd1306_WriteString("Oscillo V1", Font_11x18, White);
  ssd1306_SetCursor(0, 25);
  ssd1306_WriteString("Init...", Font_7x10, White);
  ssd1306_UpdateScreen();
  HAL_Delay(500);

  /* ═══ Init PGA849 au gain minimal (x1) ═══ */
  PGA_SetGain(PGA_GAIN_1);

  /* ═══ Activation NVIC EXTI pour le bouton B1 (PC13) ═══ */
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* ═══ Init Bluetooth USART1 ═══ */
  UART_Init(&huart1);

  const char hello[] = "Oscillo V1 OK\r\n";
  HAL_UART_Transmit(&huart1, (uint8_t*)hello, sizeof(hello) - 1U, 200U);

  /* ═══ Init mesure de fréquence hardware TIM3 Input Capture (PB4) ═══
   * FREQ_HW_Init reconfigure TIM3 (PSC=79, ARR=0xFFFF, IC CH1 front montant).
   * Doit être appelé APRÈS MX_TIM3_Init() car il réutilise le handle htim3.
   */
  FREQ_HW_Init(&htim3);

  /* ═══ Démarrage acquisition ADC + DMA ═══ */
  ACQ_Start(&hadc1, &htim2);

  /* Confirmation sur OLED */
  ssd1306_Fill(Black);
  ssd1306_SetCursor(0, 0);
  ssd1306_WriteString("Pret !", Font_11x18, White);
  ssd1306_UpdateScreen();
  HAL_Delay(300);

  /* USER CODE END 2 */

  /* Infinite loop ------------------------------------------------------------*/
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      /* ── Traiter les commandes Bluetooth ── */
      App_ProcessCommands();

      /* ── Traiter l'appui bouton B1 ── */
      App_ProcessButton();

      /* ── Attendre une demi-trame DMA ── */
      ACQ_Status_t status = ACQ_GetStatus();

      if (status != ACQ_NONE)
      {
          /*
           * On lit le pointeur et on efface le drapeau AVANT tout traitement
           * pour ne pas manquer le prochain callback ISR DMA.
           */
          const uint16_t *half = ACQ_GetReadyHalf();
          ACQ_ClearStatus();

          if (half != NULL && app_running)
          {
              /* ── Calcul min/max/moyenne (sur 512 échantillons) ── */
              uint32_t sum  = 0;
              uint16_t vmin = ACQ_ADC_MAX;
              uint16_t vmax = 0;

              for (uint16_t i = 0; i < ACQ_HALF_SIZE; i++)
              {
                  uint16_t s = half[i];
                  if (s < vmin) vmin = s;
                  if (s > vmax) vmax = s;
                  sum += s;
              }
              uint16_t vmoy = (uint16_t)(sum / ACQ_HALF_SIZE);

              /* ── Conversion en millivolts ── */
              uint16_t mv_min = ACQ_RawToMillivolts(vmin);
              uint16_t mv_max = ACQ_RawToMillivolts(vmax);
              uint16_t mv_moy = ACQ_RawToMillivolts(vmoy);

              /* ── Estimation de la fréquence ──
               * Priorité : mesure hardware TIM3 IC (PB4) si signal numérique
               * disponible, sinon fallback sur zero-crossing logiciel.
               * La mesure HW est plus précise (résolution 1 µs) mais nécessite
               * un circuit de mise en forme externe (comparateur vers PB4).
               */
              uint16_t freq_hw_val = FREQ_HW_GetHz();
              uint16_t freq_hz = (freq_hw_val > 0U)
                                 ? freq_hw_val
                                 : FREQ_Estimate(half, ACQ_HALF_SIZE,
                                                 SAMPLE_RATE_HZ);

              /* ── Rafraîchissement OLED avec throttle ── */
              oled_frame_cnt++;
              if (oled_frame_cnt >= OLED_REFRESH_EVERY)
              {
                  oled_frame_cnt = 0;
                  DISP_Update(half, ACQ_HALF_SIZE,
                              mv_min, mv_max, mv_moy,
                              freq_hz,
                              PGA_GainToMultiplier(PGA_GetCurrentGain()));
              }

              /* ── Envoi par Bluetooth (si TX DMA libre) ── */
              if (UART_IsTxReady())
              {
                  UART_SendDataFrame(half, ACQ_HALF_SIZE);
              }
          }
      }

    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  *        HSI → PLL → SYSCLK = 80 MHz
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
    Error_Handler();

  RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM            = 1;
  RCC_OscInitStruct.PLL.PLLN            = 10;
  RCC_OscInitStruct.PLL.PLLP            = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ            = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR            = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    Error_Handler();

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
    Error_Handler();
}

/**
  * @brief ADC1 : 12 bits, canal 5 (PA0), déclenché par TIM2_TRGO, DMA circulaire
  */
static void MX_ADC1_Init(void)
{
  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc1.Instance                   = ADC1;
  hadc1.Init.ClockPrescaler        = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution            = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign             = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode          = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait      = DISABLE;
  hadc1.Init.ContinuousConvMode    = DISABLE;
  hadc1.Init.NbrOfConversion       = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv      = ADC_EXTERNALTRIG_T2_TRGO;
  hadc1.Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.Overrun               = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode      = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
    Error_Handler();

  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
    Error_Handler();

  sConfig.Channel      = ADC_CHANNEL_5;
  sConfig.Rank         = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_12CYCLES_5;
  sConfig.SingleDiff   = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset       = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
    Error_Handler();
}

/**
  * @brief I2C1 : OLED SSD1306 (PB6=SCL, PB7=SDA)
  */
static void MX_I2C1_Init(void)
{
  hi2c1.Instance              = I2C1;
  hi2c1.Init.Timing           = 0x00F12981;
  hi2c1.Init.OwnAddress1      = 0;
  hi2c1.Init.AddressingMode   = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode  = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2      = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode  = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode    = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
    Error_Handler();

  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
    Error_Handler();

  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
    Error_Handler();
}

/**
  * @brief TIM2 : génère TRGO à 10 kHz pour déclencher l'ADC
  *        SYSCLK = 80 MHz, PSC = 7 → TIM_CLK = 10 MHz, ARR = 999 → 10 kHz
  */
static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef  sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig      = {0};

  htim2.Instance               = TIM2;
  htim2.Init.Prescaler         = 7;
  htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim2.Init.Period            = 999;
  htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
    Error_Handler();

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
    Error_Handler();

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
    Error_Handler();
}

/**
  * @brief TIM3 : pré-initialisation minimale du handle.
  * @note  TIM3 est entièrement reconfiguré par FREQ_HW_Init() en mode
  *        Input Capture CH1 (PB4, AF2, 1 MHz). Cette fonction ne fait
  *        qu'initialiser l'instance pour que le handle htim3 soit valide
  *        avant que FREQ_HW_Init() ne le reconfigure. On n'appelle PAS
  *        HAL_TIM_Base_Init ici pour éviter le conflit de mode Base vs IC.
  */
static void MX_TIM3_Init(void)
{
  /* Le handle htim3 sera configuré entièrement par FREQ_HW_Init().
   * On se contente de pré-remplir l'instance pour la cohérence HAL. */
  htim3.Instance = TIM3;
}

/**
  * @brief USART1 : Bluetooth HC-05 (PA9=TX, PA10=RX) à 115200 bps + DMA TX
  */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance                    = USART1;
  huart1.Init.BaudRate               = 115200;
  huart1.Init.WordLength             = UART_WORDLENGTH_8B;
  huart1.Init.StopBits               = UART_STOPBITS_1;
  huart1.Init.Parity                 = UART_PARITY_NONE;
  huart1.Init.Mode                   = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl              = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling           = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling         = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
    Error_Handler();
}

/**
  * @brief USART2 : ST-Link Virtual COM (debug)
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance                    = USART2;
  huart2.Init.BaudRate               = 115200;
  huart2.Init.WordLength             = UART_WORDLENGTH_8B;
  huart2.Init.StopBits               = UART_STOPBITS_1;
  huart2.Init.Parity                 = UART_PARITY_NONE;
  huart2.Init.Mode                   = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl              = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling           = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling         = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
    Error_Handler();
}

/**
  * @brief Active les horloges DMA et configure les priorités NVIC
  */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA1 Ch1 : ADC1 → mémoire (acquisition circulaire) — priorité la plus haute */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

  /* DMA1 Ch4 : USART1 TX → Bluetooth */
  HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);
}

/**
  * @brief GPIO :
  *          - PA4/5/6 : contrôle gain PGA849 (sortie PP)
  *          - PC13    : bouton B1 (entrée EXTI front descendant)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* Sorties PGA au niveau bas par défaut (gain x1) */
  HAL_GPIO_WritePin(GPIOA, PGA_A0_Pin | PGA_A1_Pin | PGA_A2_Pin, GPIO_PIN_RESET);

  /* Bouton B1 : PC13, EXTI front descendant (bouton actif bas) */
  GPIO_InitStruct.Pin  = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /* Broches de contrôle gain PGA849 : PA4=A0, PA5=A1, PA6=A2 */
  GPIO_InitStruct.Pin   = PGA_A0_Pin | PGA_A1_Pin | PGA_A2_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  Gestionnaire d'erreur.
  * @details Affiche "ERREUR" sur l'OLED si l'I2C est déjà initialisé,
  *          désactive les interruptions et boucle indéfiniment.
  *          En debug, mettre un point d'arrêt ici.
  */
void Error_Handler(void)
{
  __disable_irq();

  /* Tentative d'affichage de l'erreur sur l'OLED.
   * Si l'I2C n'est pas encore initialisé, cet appel est sans effet. */
  if (hi2c1.Instance != NULL && hi2c1.State != HAL_I2C_STATE_RESET)
  {
      ssd1306_Fill(Black);
      ssd1306_SetCursor(22, 18);
      ssd1306_WriteString("!! ERREUR !!", Font_7x10, White);
      ssd1306_SetCursor(14, 36);
      ssd1306_WriteString("Voir debug", Font_7x10, White);
      ssd1306_UpdateScreen();
  }

  while (1) {}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
