/*
 * pga849.c
 *
 *  Created on: Apr 13, 2026
 *      Author: gokay
 */


/**
 * @file    pga849.c
 * @brief   Implémentation du driver PGA849
 * @author  Gokay
 * @date    2026
 */

#include "pga849.h"

static PGA_Gain_t current_gain = PGA_GAIN_1;

void PGA_SetGain(PGA_Gain_t gain)
{
    gain = (PGA_Gain_t)(gain & 0x07);

    HAL_GPIO_WritePin(PGA_A0_GPIO_Port, PGA_A0_Pin,
                      (gain & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(PGA_A1_GPIO_Port, PGA_A1_Pin,
                      (gain & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(PGA_A2_GPIO_Port, PGA_A2_Pin,
                      (gain & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    current_gain = gain;
}

PGA_Gain_t PGA_GetCurrentGain(void)
{
    return current_gain;
}

uint16_t PGA_GainToMultiplier(PGA_Gain_t gain)
{
    static const uint16_t lut[8] = { 1, 2, 4, 8, 16, 32, 64, 128 };
    return lut[gain & 0x07];
}
