/**
 * @file    utils.c
 * @brief   Utilitaires généraux — réservé pour extensions futures
 * @details Ce fichier est intentionnellement vide. Il est conservé dans
 *          le projet pour accueillir des fonctions utilitaires communes
 *          (conversions, filtres, formatage) si le projet évolue.
 * @author  Gokay
 * @date    2026
 */
