/**
 * @file    acquisition.c
 * @brief   Module d'acquisition ADC/DMA/Timer
 * @author  Gokay
 * @date    2026
 *
 * Corrections apportées :
 *  - ACQ_ClearStatus() doit être appelé par main() AVANT de traiter les données
 *    (voir main.c), pas ici. Ce fichier est inchangé sur ce point mais le
 *    commentaire ci-dessous clarifie le contrat d'utilisation.
 *
 * Contrat d'utilisation de ACQ_ClearStatus() :
 *   main() doit appeler ACQ_ClearStatus() dès qu'il a lu ACQ_GetStatus() != NONE
 *   et AVANT de traiter les données, pour ne pas manquer le prochain callback ISR.
 *   Exemple correct (voir main.c) :
 *     ACQ_Status_t st = ACQ_GetStatus();
 *     const uint16_t *half = ACQ_GetReadyHalf();
 *     ACQ_ClearStatus();   ← ici, avant le traitement
 *     if (half) { ... traiter ... }
 */

#include "acquisition.h"
#include <string.h>

/* Buffer DMA circulaire – rempli en continu par le matériel.
 * Aligné sur 4 octets pour le DMA (recommandé sur Cortex-M). */
static __attribute__((aligned(4))) uint16_t adc_buffer[ACQ_BUFFER_SIZE];

/* Drapeau de synchronisation (modifié par ISR, lu par main).
 * volatile garantit que le compilateur ne met pas en cache la valeur. */
static volatile ACQ_Status_t acq_status = ACQ_NONE;

/* Handles sauvegardés lors du démarrage */
static ADC_HandleTypeDef *p_hadc = NULL;
static TIM_HandleTypeDef *p_htim = NULL;

/* ── API publique ──────────────────────────────────────────────────────── */

/**
 * @brief  Démarre l'acquisition : calibration ADC, DMA circulaire, Timer.
 * @param  hadc  Pointeur sur le handle ADC initialisé par MX_ADC1_Init()
 * @param  htim  Pointeur sur le handle TIM2 (source du TRGO ADC)
 */
void ACQ_Start(ADC_HandleTypeDef *hadc, TIM_HandleTypeDef *htim)
{
    p_hadc = hadc;
    p_htim = htim;

    memset(adc_buffer, 0, sizeof(adc_buffer));
    acq_status = ACQ_NONE;

    /* Calibration ADC single-ended (recommandé après chaque mise sous tension) */
    HAL_ADCEx_Calibration_Start(p_hadc, ADC_SINGLE_ENDED);

    /* Lancement ADC en mode DMA circulaire.
     * Le DMA déclenchera HalfCplt (moitié 0) et Cplt (moitié 1) alternativement. */
    HAL_ADC_Start_DMA(p_hadc, (uint32_t *)adc_buffer, ACQ_BUFFER_SIZE);

    /* Timer TIM2 : chaque événement UPDATE déclenche une conversion ADC via TRGO */
    HAL_TIM_Base_Start(p_htim);
}

/**
 * @brief  Arrête complètement l'acquisition (Timer + DMA).
 */
void ACQ_Stop(void)
{
    if (p_htim) HAL_TIM_Base_Stop(p_htim);
    if (p_hadc) HAL_ADC_Stop_DMA(p_hadc);
    acq_status = ACQ_NONE;
}

/**
 * @brief  Retourne l'état courant du buffer DMA.
 * @return ACQ_HALF_READY, ACQ_FULL_READY, ou ACQ_NONE
 */
ACQ_Status_t ACQ_GetStatus(void)
{
    return acq_status;
}

/**
 * @brief  Efface le drapeau de disponibilité.
 * @note   À appeler AVANT de traiter les données (voir contrat en tête de fichier).
 */
void ACQ_ClearStatus(void)
{
    acq_status = ACQ_NONE;
}

/**
 * @brief  Retourne un pointeur sur la moitié prête du buffer.
 * @return Pointeur sur adc_buffer[0] (HalfCplt) ou adc_buffer[512] (Cplt),
 *         ou NULL si aucune moitié n'est disponible.
 * @note   Valide tant qu'ACQ_ClearStatus() n'a pas été appelé.
 */
const uint16_t *ACQ_GetReadyHalf(void)
{
    switch (acq_status)
    {
        case ACQ_HALF_READY: return &adc_buffer[0];
        case ACQ_FULL_READY: return &adc_buffer[ACQ_HALF_SIZE];
        default:             return NULL;
    }
}

/**
 * @brief  Retourne un pointeur sur le buffer DMA complet (1024 samples).
 */
const uint16_t *ACQ_GetFullBuffer(void)
{
    return adc_buffer;
}

/**
 * @brief  Convertit une valeur ADC brute (0..4095) en millivolts (0..3300 mV).
 * @param  raw  Valeur ADC 12 bits
 * @return Tension en millivolts
 */
uint16_t ACQ_RawToMillivolts(uint16_t raw)
{
    return (uint16_t)(((uint32_t)raw * ACQ_VREF_MV) / ACQ_ADC_MAX);
}

/**
 * @brief  Suspend l'acquisition en arrêtant seulement le Timer.
 *         Le DMA reste armé → reprise immédiate sans recalibration.
 */
void ACQ_Suspend(void)
{
    if (p_htim) HAL_TIM_Base_Stop(p_htim);
}

/**
 * @brief  Reprend l'acquisition en relançant le Timer.
 */
void ACQ_Resume(void)
{
    if (p_htim) HAL_TIM_Base_Start(p_htim);
}

/* ── Callbacks DMA (appelés depuis les ISR du DMA) ────────────────────── */

/**
 * @brief  Callback HAL : première moitié du buffer DMA remplie (samples 0..511).
 *         Appelé depuis DMA1_Channel1_IRQHandler → HAL_DMA_IRQHandler.
 */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1)
        acq_status = ACQ_HALF_READY;
}

/**
 * @brief  Callback HAL : deuxième moitié du buffer DMA remplie (samples 512..1023).
 *         Appelé depuis DMA1_Channel1_IRQHandler → HAL_DMA_IRQHandler.
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1)
        acq_status = ACQ_FULL_READY;
}
