/*
 * uart_handler.c
 *
 *  Created on: Apr 13, 2026
 *      Author: gokay
 */

/**
 * @file    uart_handler.c
 * @brief   Implémentation du gestionnaire UART pour HC-05 Bluetooth
 * @author  Gokay
 * @date    2026
 */

#include "uart_handler.h"
#include <string.h>

static UART_HandleTypeDef *p_huart = NULL;
static uint8_t tx_buffer[UART_TX_BUF_SIZE];
static volatile uint8_t tx_busy = 0;
static uint8_t rx_byte;

/* File circulaire de commandes reçues */
static UART_Command_t rx_queue[UART_RX_QUEUE_SIZE];
static volatile uint8_t rx_head = 0;
static volatile uint8_t rx_tail = 0;

static void rx_queue_push(uint8_t type, uint8_t param)
{
    uint8_t next = (rx_head + 1U) % UART_RX_QUEUE_SIZE;
    if (next == rx_tail)
        rx_tail = (rx_tail + 1U) % UART_RX_QUEUE_SIZE;

    rx_queue[rx_head].type  = type;
    rx_queue[rx_head].param = param;
    rx_head = next;
}

/* ── API publique ──────────────────────────────────────────────────────── */

void UART_Init(UART_HandleTypeDef *huart)
{
    p_huart = huart;
    tx_busy = 0;
    rx_head = 0;
    rx_tail = 0;
    HAL_UART_Receive_IT(p_huart, &rx_byte, 1);
}

HAL_StatusTypeDef UART_SendDMA(const uint8_t *data, uint16_t size)
{
    if (tx_busy) return HAL_BUSY;
    if (data != tx_buffer)
    {
        if (size > UART_TX_BUF_SIZE) size = UART_TX_BUF_SIZE;
        memcpy(tx_buffer, data, size);
    }
    tx_busy = 1;
    HAL_StatusTypeDef s = HAL_UART_Transmit_DMA(p_huart, tx_buffer, size);
    if (s != HAL_OK) tx_busy = 0;
    return s;
}

HAL_StatusTypeDef UART_SendDataFrame(const uint16_t *samples, uint16_t nb_samples)
{
    if (tx_busy) return HAL_BUSY;
    uint16_t len = PROTO_BuildDataFrame(tx_buffer, samples, nb_samples);
    tx_busy = 1;
    HAL_StatusTypeDef s = HAL_UART_Transmit_DMA(p_huart, tx_buffer, len);
    if (s != HAL_OK) tx_busy = 0;
    return s;
}

HAL_StatusTypeDef UART_SendAck(uint8_t gain_code)
{
    if (tx_busy) return HAL_BUSY;
    uint16_t len = PROTO_BuildAckFrame(tx_buffer, gain_code);
    tx_busy = 1;
    HAL_StatusTypeDef s = HAL_UART_Transmit_DMA(p_huart, tx_buffer, len);
    if (s != HAL_OK) tx_busy = 0;
    return s;
}

HAL_StatusTypeDef UART_SendSysInfo(uint16_t sample_rate, uint8_t gain_code, uint16_t vref_mv)
{
    if (tx_busy) return HAL_BUSY;
    uint16_t len = PROTO_BuildSysInfoFrame(tx_buffer, sample_rate, gain_code, vref_mv);
    tx_busy = 1;
    HAL_StatusTypeDef s = HAL_UART_Transmit_DMA(p_huart, tx_buffer, len);
    if (s != HAL_OK) tx_busy = 0;
    return s;
}

uint8_t UART_HasPendingCommand(void)
{
    return (rx_head != rx_tail) ? 1U : 0U;
}

uint8_t UART_GetCommand(UART_Command_t *cmd)
{
    if (rx_head == rx_tail) return 0;
    cmd->type  = rx_queue[rx_tail].type;
    cmd->param = rx_queue[rx_tail].param;
    rx_tail = (rx_tail + 1U) % UART_RX_QUEUE_SIZE;
    return 1;
}

uint8_t UART_IsTxReady(void)
{
    return (tx_busy == 0) ? 1U : 0U;
}

/* ── Callbacks HAL (appelés depuis les ISR) ────────────────────────────── */

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
        tx_busy = 0;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        uint8_t cmd_type = PROTO_ParseCommand(rx_byte);
        if (cmd_type != PROTO_PARSED_NONE)
        {
            uint8_t param = 0;
            if (cmd_type == PROTO_PARSED_GAIN)
                param = rx_byte - PROTO_RX_GAIN_MIN;
            rx_queue_push(cmd_type, param);
        }
        HAL_UART_Receive_IT(p_huart, &rx_byte, 1);
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
        HAL_UART_Receive_IT(p_huart, &rx_byte, 1);
}
