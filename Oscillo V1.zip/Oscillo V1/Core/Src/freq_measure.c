/**
 * @file    freq_measure.c
 * @brief   Mesure de fréquence par comptage de passages à zéro (zero-crossing)
 * @author  Gokay
 * @date    2026
 *
 * Principe :
 *   On compte le nombre de fronts montants par rapport à la valeur moyenne
 *   du buffer (ce qui constitue le "zéro" local du signal).
 *   On divise ensuite la fréquence d'échantillonnage par le nombre moyen
 *   de samples par période pour obtenir la fréquence.
 *
 *   Exemple : 10 kHz, 512 samples, 5 fronts montants comptés
 *     → période_moy = 512 / 5 = 102 samples
 *     → freq = 10000 / 102 ≈ 98 Hz
 */

#include "freq_measure.h"

uint16_t FREQ_Estimate(const uint16_t *samples, uint16_t nb_samples,
                       uint32_t sample_rate)
{
    if (samples == NULL || nb_samples < 4U)
        return 0U;

    /* ── 1. Calcul de la moyenne (référence DC locale) ── */
    uint32_t sum = 0;
    for (uint16_t i = 0; i < nb_samples; i++)
        sum += samples[i];
    uint16_t mean = (uint16_t)(sum / nb_samples);

    /* ── 2. Comptage des fronts montants ── */
    uint16_t crossings = 0;
    for (uint16_t i = 1; i < nb_samples; i++)
    {
        if (samples[i - 1] < mean && samples[i] >= mean)
            crossings++;
    }

    /* Aucun croisement → signal DC ou très basse fréquence */
    if (crossings == 0U)
        return 0U;

    /* ── 3. Calcul de la fréquence ── */
    /* samples par période = nb_samples / nb_périodes = nb_samples / crossings */
    /* freq = sample_rate / samples_par_periode = sample_rate * crossings / nb_samples */
    uint32_t freq = (sample_rate * crossings) / nb_samples;

    /* Limiter la plage affichée : en dessous de 5 Hz on retourne 0 */
    if (freq < 5U)
        return 0U;

    /* Plafonner à la fréquence de Nyquist */
    if (freq > sample_rate / 2U)
        freq = sample_rate / 2U;

    return (uint16_t)freq;
}
